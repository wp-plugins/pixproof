<?php return array
	(

	# Hidden fields

		'settings_saved_once' => '0',

	# "Post Types" fields
	'enable_pixproof_gallery' => true,

		'pixproof_single_item_label' => __('Proof Gallery', 'pixproof_txtd'),
		'pixproof_multiple_items_label' => __('Proof Galleries', 'pixproof_txtd'),
		'pixproof_change_single_item_slug' => false,
		'pixproof_gallery_new_single_item_slug' => 'pixproof_gallery'

	); # config
